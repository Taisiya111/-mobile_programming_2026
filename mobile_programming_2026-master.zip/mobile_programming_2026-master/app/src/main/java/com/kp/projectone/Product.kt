package com.kp.projectone

data class Product(
    val id: Int,
    val name: String,
    val shortDescription: String,
    val imageUrl: String

)
